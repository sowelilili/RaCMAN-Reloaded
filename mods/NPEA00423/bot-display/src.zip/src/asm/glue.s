# 64-bit glue between the game (PPC64 ABI) and the 32-bit C code in mod.c.
#
# Entries give the C function a full 64-bit frame of its own, so nothing the 32-bit
# prologue writes lands in the game's frame. Thunks give the game function a full frame
# (LR save at +16, parameter save area at +48) when the C code calls back into the game.

.macro ENTRY name, cfunc
	.section .text.\name, "ax"
	.globl \name
\name:
	stdu	r1,-160(r1)
	mflr	r0
	std	r0,144(r1)
	bl	\cfunc
	ld	r0,144(r1)
	mtlr	r0
	addi	r1,r1,160
	blr
.endm

.macro THUNK name, target
	.section .text.\name, "ax"
	.globl \name
\name:
	stdu	r1,-128(r1)
	mflr	r0
	std	r0,112(r1)
	bl	\target
	ld	r0,112(r1)
	mtlr	r0
	addi	r1,r1,128
	blr
.endm

ENTRY draw_hud_entry, main_loop

THUNK FontPrint, game_FontPrint
THUNK sprintf, game_sprintf
