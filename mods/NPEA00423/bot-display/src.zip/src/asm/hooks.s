# Macro for creating raw patches.
.macro PATCH addr, name, instr:vararg
	.section .hook.\name 
	\instr
.endm 

# --- Entrypoints ---
# Once per rendered frame: a nop in the 2D pass (0x1ce1d8), where FontPrint can draw.
# Each display mod has its own nop there, so they can all be on together.
PATCH 0x1ce248, draw_hud_hook, bl draw_hud_entry
